import numpy as np
from scipy.integrate import simps
import matplotlib.pyplot as plt

lam, I = np.loadtxt('linijaHa.txt', unpack = True)

EW = simps(1-I,lam)

ind_min = np.argmin(I)
l0 = lam[ind_min]
dl = EW / 2

x_fill = [-dl,dl]
y_fill = [1,1]

plt.plot(lam - l0, I)
plt.xlabel('$\lambda - \lambda _0$ [nm]', fontsize = 14)
plt.ylabel('$I_\lambda / I_c$', fontsize = 14)
plt.fill_between(x_fill, y_fill, facecolor = 'orange', alpha = 0.4)
plt.annotate ('', (-dl, 0.1), (dl, 0.1), arrowprops={'arrowstyle':'<->'})
plt.text(-0.55, 0.12, 'W')
plt.title('Ekvivalentna sirina linije je $4.87\AA$', fontsize = 16)
plt.savefig('EW.png')

print ('Ekvivalentna sirina: ', EW, '[A]') 